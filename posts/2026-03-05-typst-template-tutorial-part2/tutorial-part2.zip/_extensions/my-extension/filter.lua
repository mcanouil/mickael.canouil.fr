return require(quarto.utils.resolve_path("typst-markdown.lua"):gsub('%.lua$', ''))
