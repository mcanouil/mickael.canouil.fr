local M = {}

--- Return default div/span mappings for all components
function M.get_builtin_mappings()
  return {
    div = {
      ['highlight'] = { wrapper = 'my-highlight', arguments = false },
      ['panel'] = { wrapper = 'my-panel', arguments = true },
      ['quote-card'] = { wrapper = 'quote-card', arguments = true },
    },
    span = {
      ['badge'] = { wrapper = 'my-badge', arguments = true },
    },
  }
end

--- Parse simple or detailed config format
local function parse_and_validate_config(config, class)
  if type(config) == 'string' or (type(config) == 'table' and config.t == 'MetaInlines') then
    local fn_name = pandoc.utils.stringify(config)
    return { wrapper = fn_name, arguments = false }
  elseif type(config) == 'table' then
    local fn_name = config['function'] or config['wrapper']
    if fn_name then
      fn_name = pandoc.utils.stringify(fn_name)
      local arguments = false
      if config['arguments'] then
        local arg_str = pandoc.utils.stringify(config['arguments'])
        arguments = arg_str == 'true'
      end
      return { wrapper = fn_name, arguments = arguments }
    end
  end
  return nil
end

--- Read extensions.typst-markdown from YAML metadata
function M.load_element_mappings(meta)
  local user_mappings = { div = {}, span = {} }

  local extension_config = meta.extensions and meta.extensions['typst-markdown']
  if not extension_config then
    return user_mappings
  end

  local element_types = {
    { config_key = 'divs', mappings_key = 'div' },
    { config_key = 'spans', mappings_key = 'span' },
  }

  for _, element_type in ipairs(element_types) do
    if extension_config[element_type.config_key] then
      for class, element_config in pairs(extension_config[element_type.config_key]) do
        local parsed = parse_and_validate_config(element_config, class)
        if parsed then
          user_mappings[element_type.mappings_key][class] = parsed
        end
      end
    end
  end

  return user_mappings
end

--- Merge configurations: user overrides built-in
function M.merge_configurations(builtin, user)
  local merged = {}
  for class, cfg in pairs(builtin) do
    merged[class] = cfg
  end
  for class, cfg in pairs(user) do
    merged[class] = cfg
  end
  return merged
end

return M
