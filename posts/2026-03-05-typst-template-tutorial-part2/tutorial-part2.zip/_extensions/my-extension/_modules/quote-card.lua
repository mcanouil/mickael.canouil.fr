local wrapper = require(quarto.utils.resolve_path("_modules/wrapper.lua"):gsub('%.lua$', ''))

local M = {}

--- Process quote card: extract author from last heading or attributes
function M.process_div(div, config)
  local attrs = wrapper.attributes_to_table(div)

  if not attrs['author'] and #div.content > 0 then
    local last_elem = div.content[#div.content]
    if last_elem.t == 'Header' then
      attrs['author'] = pandoc.utils.stringify(last_elem.content)
      local new_content = {}
      for i = 1, #div.content - 1 do
        table.insert(new_content, div.content[i])
      end
      div.content = new_content
    end
  end

  local opening, closing = wrapper.build_typst_block_wrappers(config, attrs)
  local result = { pandoc.RawBlock('typst', opening) }
  for _, item in ipairs(div.content) do
    table.insert(result, item)
  end
  table.insert(result, pandoc.RawBlock('typst', closing))
  return result
end

return M
