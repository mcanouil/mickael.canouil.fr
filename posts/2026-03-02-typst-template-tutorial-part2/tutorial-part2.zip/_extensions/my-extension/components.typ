// ── Helpers ──────────────────────────────────────────────────────────

// Check whether a value has meaningful content
#let has-content(value) = {
  value != none and value != "" and value != (:) and value != ()
}

// Map accent name to colour (self-contained replacement for callout-colour)
#let get-accent-colour(name) = {
  if name == "note" { rgb("#0066cc") }
  else if name == "tip" { rgb("#009955") }
  else if name == "warning" { rgb("#cc6600") }
  else if name == "important" { rgb("#cc0000") }
  else { luma(128) }
}

// Simplified WCAG contrast helper (lightness heuristic, demonstrative only).
// Iteratively darkens or lightens `fg` until the perceived contrast
// against `bg` is sufficient.  This is NOT a full WCAG luminance
// calculation but works well enough for the tutorial.
#let ensure-contrast(fg, bg, min-ratio: 4.5) = {
  let bg-light = bg.components().at(0, default: 50%)
  let fg-light = fg.components().at(0, default: 50%)

  // Determine direction: if bg is light we want dark text, and vice versa
  if bg-light > 50% {
    // Light background – darken foreground
    let out = fg
    let i = 0
    while i < 8 {
      let l = out.components().at(0, default: 50%)
      if l < 35% { return out }
      out = out.darken(15%)
      i = i + 1
    }
    out
  } else {
    // Dark background – lighten foreground
    let out = fg
    let i = 0
    while i < 8 {
      let l = out.components().at(0, default: 50%)
      if l > 65% { return out }
      out = out.lighten(15%)
      i = i + 1
    }
    out
  }
}

// ── Badges (WCAG-aware) ─────────────────────────────────────────────

// Compute badge colours with dark-mode support
#let get-badge-colours(colour, colours) = {
  let fg-components = colours.foreground.components()
  let is-dark-mode = fg-components.at(0, default: 0%) > 50%

  let base = if colour == "success" { get-accent-colour("tip") }
    else if colour == "warning" { get-accent-colour("warning") }
    else if colour == "danger" { get-accent-colour("important") }
    else if colour == "info" { get-accent-colour("note") }
    else { colours.muted }

  let background = if is-dark-mode { base.darken(60%) }
    else { base.lighten(80%) }

  let text-colour = ensure-contrast(base, background, min-ratio: 4.5)

  (background: background, border: base, text: text-colour)
}

// Inline badge component (WCAG-aware version)
#let simple-badge(content, colour: "neutral", colours: (:)) = {
  let badge-colours = if colours.len() > 0 {
    get-badge-colours(colour, colours)
  } else {
    // Fallback when no colour scheme supplied
    let base = get-accent-colour(
      if colour == "success" { "tip" }
      else if colour == "warning" { "warning" }
      else if colour == "danger" { "important" }
      else if colour == "info" { "note" }
      else { "note" }
    )
    (background: base.lighten(80%), border: base.lighten(40%), text: base)
  }

  box(
    fill: badge-colours.background,
    stroke: 0.5pt + badge-colours.border,
    radius: 4pt,
    inset: 0.25em,
    text(size: 0.85em, fill: badge-colours.text, content),
  )
}

// ── Panels ──────────────────────────────────────────────────────────

// Panel colour lookup by style
#let get-panel-colours(style, colours) = {
  if style == "info" {
    (background: rgb("#0066cc").lighten(90%), border: rgb("#0066cc").lighten(50%), title: rgb("#0066cc"), content: luma(30))
  } else if style == "success" {
    (background: rgb("#009955").lighten(90%), border: rgb("#009955").lighten(50%), title: rgb("#009955"), content: luma(30))
  } else if style == "warning" {
    (background: rgb("#cc6600").lighten(90%), border: rgb("#cc6600").lighten(50%), title: rgb("#cc6600"), content: luma(30))
  } else if style == "danger" {
    (background: rgb("#cc0000").lighten(90%), border: rgb("#cc0000").lighten(50%), title: rgb("#cc0000"), content: luma(30))
  } else {
    (background: luma(245), border: luma(200), title: luma(60), content: luma(30))
  }
}

// Block panel component
#let render-panel(
  content,
  title: none,
  style: "subtle",
  icon: none,
  colours: (:),
  breakable: false,
) = {
  let panel-colours = get-panel-colours(style, colours)

  let title-display = if has-content(title) {
    block(
      below: 0.8em,
      text(
        size: 1.1em,
        weight: "semibold",
        fill: panel-colours.title,
        title,
      ),
    )
  }

  block(
    width: 100%,
    fill: panel-colours.background,
    stroke: 1pt + panel-colours.border,
    radius: 8pt,
    inset: 1.2em,
    breakable: breakable,
    {
      if title-display != none { title-display }
      text(fill: panel-colours.content, content)
    },
  )
}

// ── Quote Card ──────────────────────────────────────────────────────

#let QUOTE-CARD-RADIUS = 8pt
#let QUOTE-CARD-INSET = 1.5em
#let QUOTE-MARK-SIZE = 3em

// Render a styled quote card
#let render-quote-card(
  content,
  author: none,
  source: none,
  colours: (:),
) = {
  let bg = colours.at("background", default: luma(250))
  let fg = colours.at("foreground", default: luma(50))
  let muted = colours.at("muted", default: luma(128))
  let accent = get-accent-colour("note")

  block(
    width: 100%,
    fill: bg,
    stroke: (left: 4pt + accent),
    radius: (right: QUOTE-CARD-RADIUS),
    inset: QUOTE-CARD-INSET,
    {
      // Opening quote mark
      place(
        top + left,
        dx: -0.5em,
        dy: -0.3em,
        text(size: QUOTE-MARK-SIZE, fill: accent.lighten(60%), sym.quote.l.double),
      )

      // Quote content
      pad(left: 1em, right: 1em)[
        #text(style: "italic", fill: fg, content)
      ]

      // Attribution line
      if author != none or source != none {
        v(0.8em)
        align(right)[
          #text(fill: muted)[
            #sym.dash.em
            #if author != none { [ #author] }
            #if source != none { [, #emph(source)] }
          ]
        ]
      }
    },
  )
}

