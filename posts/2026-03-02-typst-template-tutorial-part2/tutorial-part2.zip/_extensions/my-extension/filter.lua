-- ═══════════════════════════════════════════════════════════════════
-- filter.lua — Single-file Lua filter for Part 2 tutorial assets
-- Organised in sections matching the tutorial module names.
-- ═══════════════════════════════════════════════════════════════════

-- ── typst-utils section ─────────────────────────────────────────────

--- Convert a Lua value to Typst syntax
local function typst_value(value)
  if value == nil then
    return 'none'
  elseif type(value) == 'boolean' then
    return value and 'true' or 'false'
  elseif type(value) == 'number' then
    return tostring(value)
  elseif type(value) == 'string' then
    -- Typst keywords pass through unquoted
    if value == 'none' or value == 'auto' or value == 'true' or value == 'false' then
      return value
    end
    -- Typst length units pass through unquoted
    if value:match('^%-?%d+%.?%d*[a-z%%]+$') then
      return value
    end
    -- Quote strings, escaping internal quotes
    return '"' .. value:gsub('"', '\\"') .. '"'
  else
    return '"' .. tostring(value):gsub('"', '\\"') .. '"'
  end
end

--- Convert element attributes to a plain Lua table
local function attributes_to_table(element)
  local attrs = {}
  for key, value in pairs(element.attributes) do
    attrs[key] = value
  end
  return attrs
end

--- Build attribute string for Typst function calls
local function build_attribute_string(attrs)
  local parts = {}
  for key, value in pairs(attrs) do
    local typst_key = key:gsub('%-', '-')
    local typst_val = typst_value(value)
    table.insert(parts, string.format('%s: %s', typst_key, typst_val))
  end
  return table.concat(parts, ', ')
end

-- ── wrapper section (factories) ─────────────────────────────────────

--- Extract first heading as title attribute
local function extract_first_heading_as_title(el, attrs)
  if not attrs['title'] and #el.content > 0 then
    local first_elem = el.content[1]
    if first_elem.t == 'Header' then
      attrs['title'] = pandoc.utils.stringify(first_elem.content)
      local new_content = {}
      for i = 2, #el.content do
        table.insert(new_content, el.content[i])
      end
      el.content = new_content
    end
  end
end

--- Build Typst block wrappers with optional attributes
local function build_typst_block_wrappers(config, attrs)
  local has_attributes = next(attrs) ~= nil

  if has_attributes or config.arguments then
    local attr_string = build_attribute_string(attrs)
    return string.format('#%s(%s)[', config.wrapper, attr_string), ']'
  else
    return string.format('#%s[', config.wrapper), ']'
  end
end

--- Build wrapped content for a div
local function build_wrapped_content(div, config, should_extract_title)
  local attrs = attributes_to_table(div)
  if should_extract_title then
    extract_first_heading_as_title(div, attrs)
  end

  local opening, closing = build_typst_block_wrappers(config, attrs)
  local result = { pandoc.RawBlock('typst', opening) }
  for _, item in ipairs(div.content) do
    table.insert(result, item)
  end
  table.insert(result, pandoc.RawBlock('typst', closing))
  return result
end

--- Factory: create handler for wrapped content components
local function create_wrapped_handler(should_extract_title)
  return function(div, config)
    return build_wrapped_content(div, config, should_extract_title)
  end
end

-- ── config section ──────────────────────────────────────────────────

--- Return default div/span mappings for all components
local function get_builtin_mappings()
  return {
    div = {
      ['highlight'] = { wrapper = 'my-highlight', arguments = false },
      ['panel'] = { wrapper = 'my-panel', arguments = true },
      ['quote-card'] = { wrapper = 'quote-card', arguments = true },
    },
    span = {
      ['badge'] = { wrapper = 'my-badge', arguments = true },
    },
  }
end

--- Parse simple or detailed config format
local function parse_and_validate_config(config, class)
  if type(config) == 'string' or (type(config) == 'table' and config.t == 'MetaInlines') then
    local fn_name = pandoc.utils.stringify(config)
    return { wrapper = fn_name, arguments = false }
  elseif type(config) == 'table' then
    local fn_name = config['function'] or config['wrapper']
    if fn_name then
      fn_name = pandoc.utils.stringify(fn_name)
      local arguments = false
      if config['arguments'] then
        local arg_str = pandoc.utils.stringify(config['arguments'])
        arguments = arg_str == 'true'
      end
      return { wrapper = fn_name, arguments = arguments }
    end
  end
  return nil
end

--- Read extensions.typst-markdown from YAML metadata
local function load_element_mappings(meta)
  local user_mappings = { div = {}, span = {} }

  local extension_config = meta.extensions and meta.extensions['typst-markdown']
  if not extension_config then
    return user_mappings
  end

  local element_types = {
    { config_key = 'divs', mappings_key = 'div' },
    { config_key = 'spans', mappings_key = 'span' },
  }

  for _, element_type in ipairs(element_types) do
    if extension_config[element_type.config_key] then
      for class, config in pairs(extension_config[element_type.config_key]) do
        local parsed = parse_and_validate_config(config, class)
        if parsed then
          user_mappings[element_type.mappings_key][class] = parsed
        end
      end
    end
  end

  return user_mappings
end

--- Merge configurations: user overrides built-in
local function merge_configurations(builtin, user)
  local merged = {}
  for class, config in pairs(builtin) do
    merged[class] = config
  end
  for class, config in pairs(user) do
    merged[class] = config
  end
  return merged
end

-- ── Custom handlers ─────────────────────────────────────────────────

--- Process quote card: extract author from last heading or attributes
local function process_quote_card(div, config)
  local attrs = attributes_to_table(div)

  -- Extract author from last heading if not in attributes
  if not attrs['author'] and #div.content > 0 then
    local last_elem = div.content[#div.content]
    if last_elem.t == 'Header' then
      attrs['author'] = pandoc.utils.stringify(last_elem.content)
      local new_content = {}
      for i = 1, #div.content - 1 do
        table.insert(new_content, div.content[i])
      end
      div.content = new_content
    end
  end

  local opening, closing = build_typst_block_wrappers(config, attrs)
  local result = { pandoc.RawBlock('typst', opening) }
  for _, item in ipairs(div.content) do
    table.insert(result, item)
  end
  table.insert(result, pandoc.RawBlock('typst', closing))
  return result
end

-- ── Dispatch and filters ────────────────────────────────────────────

-- Custom handlers for specific classes
local DIV_HANDLERS = {
  ['quote-card'] = process_quote_card,
}

-- Factory handlers for config-based classes
local DIV_FACTORY_HANDLERS = {
  ['panel'] = create_wrapped_handler(true),
  ['highlight'] = create_wrapped_handler(false),
}

-- Merged configuration (populated by Meta filter)
local merged_div_config = {}
local merged_span_config = {}

return {
  {
    -- Meta filter: initialise merged configuration
    Meta = function(meta)
      local builtin = get_builtin_mappings()
      local user = load_element_mappings(meta)

      merged_div_config = merge_configurations(builtin.div, user.div)
      merged_span_config = merge_configurations(builtin.span, user.span)
    end,
  },
  {
    -- Div filter
    Div = function(div)
      if not quarto.doc.is_format('typst') then
        return div
      end

      -- Check each class against handlers and config
      for _, class in ipairs(div.classes) do
        local config = merged_div_config[class]
        if config then
          -- Custom handlers first
          if DIV_HANDLERS[class] then
            return DIV_HANDLERS[class](div, config)
          end

          -- Factory handlers
          if DIV_FACTORY_HANDLERS[class] then
            return DIV_FACTORY_HANDLERS[class](div, config)
          end

          -- Default: simple wrapped handler (no title extraction)
          return build_wrapped_content(div, config, false)
        end
      end

      return div
    end,

    -- Span filter
    Span = function(span)
      if not quarto.doc.is_format('typst') then
        return span
      end

      for _, class in ipairs(span.classes) do
        local config = merged_span_config[class]
        if config then
          local content = pandoc.utils.stringify(span.content)
          local attrs = attributes_to_table(span)
          local attr_string = build_attribute_string(attrs)

          local typst_code
          if attr_string ~= '' then
            typst_code = string.format('#%s(%s)[%s]', config.wrapper, attr_string, content)
          else
            typst_code = string.format('#%s[%s]', config.wrapper, content)
          end

          return pandoc.RawInline('typst', typst_code)
        end
      end

      return span
    end,
  },
}
