// Include component definitions via template partial
$components.typ()$

// Colour scheme for the document
#let get-colours(mode: "light") = {
  if mode == "dark" {
    (background: luma(30), foreground: luma(230), muted: luma(150))
  } else {
    (background: luma(255), foreground: luma(30), muted: luma(100))
  }
}

// Include wrapper functions via template partial
$typst-show.typ()$

// Render header includes and body
$for(header-includes)$
$header-includes$
$endfor$

$body$
