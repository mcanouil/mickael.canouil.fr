-- shortcodes.lua — Status badge shortcode for Part 2 tutorial
-- Shortcodes run in a separate Lua environment, so we include a
-- minimal typst_value helper locally.

--- Convert a Lua value to Typst syntax (minimal version)
local function typst_value(value)
  if value == nil or value == '' then
    return 'none'
  elseif value == 'true' or value == 'false' or value == 'none' or value == 'auto' then
    return value
  elseif tonumber(value) then
    return tostring(value)
  else
    return '"' .. tostring(value):gsub('"', '\\"') .. '"'
  end
end

return {
  ['status-badge'] = function(args, kwargs, meta)
    if not quarto.doc.is_format('typst') then
      return pandoc.Null()
    end

    local label = pandoc.utils.stringify(kwargs['label'] or 'Status')
    local style = pandoc.utils.stringify(kwargs['style'] or 'info')

    local typst_code = string.format(
      '#status-badge(label: %s, style: %s)',
      typst_value(label),
      typst_value(style)
    )

    return pandoc.RawInline('typst', typst_code)
  end,
}
