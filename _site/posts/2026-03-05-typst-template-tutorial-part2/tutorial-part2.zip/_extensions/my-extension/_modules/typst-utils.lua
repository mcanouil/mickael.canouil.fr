local M = {}

--- Convert a Lua value to Typst syntax
function M.typst_value(value)
  if value == nil then
    return 'none'
  elseif type(value) == 'boolean' then
    return value and 'true' or 'false'
  elseif type(value) == 'number' then
    return tostring(value)
  elseif type(value) == 'string' then
    if value == 'none' or value == 'auto' or value == 'true' or value == 'false' then
      return value
    end
    if value:match('^%-?%d+%.?%d*[a-z%%]+$') then
      return value
    end
    return '"' .. value:gsub('"', '\\"') .. '"'
  else
    return '"' .. tostring(value):gsub('"', '\\"') .. '"'
  end
end

--- Convert element attributes to a plain Lua table
function M.attributes_to_table(element)
  local attrs = {}
  for key, value in pairs(element.attributes) do
    attrs[key] = value
  end
  return attrs
end

--- Build attribute string for Typst function calls
function M.build_attribute_string(attrs)
  local parts = {}
  for key, value in pairs(attrs) do
    local typst_key = key
    local typst_val = M.typst_value(value)
    table.insert(parts, string.format('%s: %s', typst_key, typst_val))
  end
  return table.concat(parts, ', ')
end

return M
