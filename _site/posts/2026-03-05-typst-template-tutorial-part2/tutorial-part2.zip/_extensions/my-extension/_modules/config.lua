local M = {}

local function meta_get(meta_map, wanted_key)
  if type(meta_map) ~= 'table' then
    return nil
  end

  if meta_map[wanted_key] ~= nil then
    return meta_map[wanted_key]
  end

  -- Pandoc meta maps may use non-string key objects; normalise via stringify.
  for key, value in pairs(meta_map) do
    if pandoc.utils.stringify(key) == wanted_key then
      return value
    end
  end

  return nil
end

--- Return default div/span mappings for all components
function M.get_builtin_mappings()
  return {
    div = {
      ['highlight'] = { wrapper = 'my-highlight', arguments = false },
      ['panel'] = { wrapper = 'my-panel', arguments = true },
      ['quote-card'] = { wrapper = 'quote-card', arguments = true },
    },
    span = {
      ['badge'] = { wrapper = 'my-badge', arguments = true },
    },
  }
end

--- Parse simple or detailed config format
local function parse_mapping(config)
  if type(config) == 'string' then
    return { wrapper = config, arguments = false }
  end

  if type(config) ~= 'table' then
    return nil
  end

  local fn_name = meta_get(config, 'function') or meta_get(config, 'wrapper')
  if fn_name then
    local arg_value = meta_get(config, 'arguments')
    return {
      wrapper = pandoc.utils.stringify(fn_name),
      arguments = arg_value and pandoc.utils.stringify(arg_value) == 'true' or false,
    }
  end

  -- Simple form: `custom-highlight: my-custom-highlight`.
  local simple_fn = pandoc.utils.stringify(config)
  if simple_fn ~= '' then
    return { wrapper = simple_fn, arguments = false }
  end

  return nil
end

--- Read extensions.typst-markdown from YAML metadata
function M.load_element_mappings(meta)
  local user_mappings = { div = {}, span = {} }

  local extension_config = meta.extensions and meta_get(meta.extensions, 'typst-markdown')
  if not extension_config then
    return user_mappings
  end

  local element_types = {
    { config_key = 'divs', mappings_key = 'div' },
    { config_key = 'spans', mappings_key = 'span' },
  }

  for _, element_type in ipairs(element_types) do
    local entries = meta_get(extension_config, element_type.config_key)
    if entries then
      for class, element_config in pairs(entries) do
        -- Class keys may arrive as metadata objects; always normalise to plain strings.
        local class_name = pandoc.utils.stringify(class)
        local parsed = parse_mapping(element_config)
        if class_name ~= '' and parsed then
          user_mappings[element_type.mappings_key][class_name] = parsed
        end
      end
    end
  end

  return user_mappings
end

--- Merge configurations: user overrides built-in
function M.merge_configurations(builtin, user)
  local merged = {}
  for class, cfg in pairs(builtin) do
    merged[class] = cfg
  end
  for class, cfg in pairs(user) do
    merged[class] = cfg
  end
  return merged
end

return M
