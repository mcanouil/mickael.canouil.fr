// Define brand mode with default fallback
#let effective-brand-mode = "$if(brand-mode)$$brand-mode$$else$light$endif$"

// ── Wrapper functions ───────────────────────────────────────────────
// Each wrapper injects runtime colours so Lua only emits function names.

// Badge wrapper (WCAG-aware)
#let my-badge(content, colour: "neutral") = {
  simple-badge(
    content,
    colour: colour,
    colours: get-colours(mode: effective-brand-mode),
  )
}

// Highlight wrapper (no title extraction)
#let my-highlight(content) = {
  let colours = get-colours(mode: effective-brand-mode)
  let accent = get-accent-colour("tip")
  block(
    width: 100%,
    fill: accent.lighten(90%),
    stroke: 1pt + accent.lighten(50%),
    radius: 4pt,
    inset: 1em,
    text(fill: colours.foreground, content),
  )
}

// Panel wrapper
#let my-panel(content, ..args) = {
  render-panel(
    content,
    colours: get-colours(mode: effective-brand-mode),
    ..args,
  )
}

// Quote card wrapper
#let quote-card(content, ..args) = {
  render-quote-card(
    content,
    colours: get-colours(mode: effective-brand-mode),
    ..args,
  )
}

// User-defined custom highlight (config system demo)
#let my-custom-highlight(content) = {
  let colours = get-colours(mode: effective-brand-mode)
  let accent = get-accent-colour("warning")
  block(
    width: 100%,
    fill: accent.lighten(85%),
    stroke: 1pt + accent.lighten(40%),
    radius: 4pt,
    inset: 1em,
    text(fill: colours.foreground, content),
  )
}
