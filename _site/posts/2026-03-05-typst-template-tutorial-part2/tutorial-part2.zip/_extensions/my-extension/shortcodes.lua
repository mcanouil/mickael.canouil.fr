return {
  ['status-badge'] = function(args, kwargs, meta)
    if not quarto.doc.is_format('typst') then
      return pandoc.Null()
    end

    local label = pandoc.utils.stringify(kwargs['label'] or 'Status')
    local style = pandoc.utils.stringify(kwargs['style'] or 'info')

    local typst_code = string.format(
      '#my-badge(colour: "%s")[%s]',
      style,
      label
    )

    return pandoc.RawInline('typst', typst_code)
  end,
}
