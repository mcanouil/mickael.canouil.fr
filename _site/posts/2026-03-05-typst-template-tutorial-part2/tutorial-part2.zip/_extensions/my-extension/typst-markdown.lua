local function require_local(path)
  return require(quarto.utils.resolve_path(path):gsub('%.lua$', ''))
end

local config = require_local("_modules/config.lua")
local quote_card = require_local("_modules/quote-card.lua")
local wrapper = require_local("_modules/wrapper.lua")
local typst_utils = require_local("_modules/typst-utils.lua")

local DIV_HANDLERS = {
  ['quote-card'] = quote_card.process_div,
}

local DIV_FACTORY_HANDLERS = {
  ['panel'] = wrapper.create_wrapped_handler(true),
  ['highlight'] = wrapper.create_wrapped_handler(false),
}

local merged_div_config = {}
local merged_span_config = {}

return {
  {
    -- Meta filter: initialise merged configuration
    Meta = function(meta)
      local builtin = config.get_builtin_mappings()
      local user = config.load_element_mappings(meta)

      merged_div_config = config.merge_configurations(builtin.div, user.div)
      merged_span_config = config.merge_configurations(builtin.span, user.span)

    end,
  },
  {
    -- Div filter
    Div = function(div)
      if not quarto.doc.is_format('typst') then
        return div
      end

      -- Check each class against handlers and config
      for _, class in ipairs(div.classes) do
        local class_config = merged_div_config[class]
        if class_config then
          -- Custom handlers first
          if DIV_HANDLERS[class] then
            return DIV_HANDLERS[class](div, class_config)
          end

          -- Factory handlers
          if DIV_FACTORY_HANDLERS[class] then
            return DIV_FACTORY_HANDLERS[class](div, class_config)
          end

          -- Default: simple wrapped handler (no title extraction)
          return wrapper.build_wrapped_content(div, class_config, false)
        end
      end

      return div
    end,

    -- Span filter
    Span = function(span)
      if not quarto.doc.is_format('typst') then
        return span
      end

      for _, class in ipairs(span.classes) do
        local class_config = merged_span_config[class]
        if class_config then
          local content = pandoc.utils.stringify(span.content)
          local attrs = typst_utils.attributes_to_table(span)
          local attr_string = typst_utils.build_attribute_string(attrs)

          local typst_code
          if attr_string ~= '' then
            typst_code = string.format('#%s(%s)[%s]', class_config.wrapper, attr_string, content)
          else
            typst_code = string.format('#%s[%s]', class_config.wrapper, content)
          end

          return pandoc.RawInline('typst', typst_code)
        end
      end

      return span
    end,
  },
}
