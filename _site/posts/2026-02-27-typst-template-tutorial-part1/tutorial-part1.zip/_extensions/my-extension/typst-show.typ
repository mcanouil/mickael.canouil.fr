// Define brand mode with default fallback
#let effective-brand-mode = "$if(brand-mode)$$brand-mode$$else$light$endif$"

// Wrapper for .panel divs - injects colours at render time
#let my-panel(content, ..args) = {
  render-panel(
    content,
    colours: get-colours(mode: effective-brand-mode),
    ..args,
  )
}
